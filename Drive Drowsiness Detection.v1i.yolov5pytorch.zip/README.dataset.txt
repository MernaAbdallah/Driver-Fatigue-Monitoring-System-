# Drive Drowsiness Detection > 2023-10-22 11:11pm
https://universe.roboflow.com/detection-4nooy/drive-drowsiness-detection

Provided by a Roboflow user
License: CC BY 4.0

